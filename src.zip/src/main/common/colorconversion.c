/*
 * This file is part of Cleanflight.
 *
 * Cleanflight is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Cleanflight is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Cleanflight.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "stdint.h"
#include "maths.h"

#include "color.h"
#include "colorconversion.h"


/*
 * Source below found here: http://www.kasperkamperman.com/blog/arduino/arduino-programming-hsb-to-rgb/
 */

rgbColor24bpp_t* hsvToRgb24(const hsvColor_t* c)
{
    static rgbColor24bpp_t r;

    uint16_t val = c->v;
    uint16_t sat = 255 - c->s;
    uint32_t base;
    uint16_t hue = c->h;

    if (sat == 0) { // Acromatic color (gray). Hue doesn't mind.
        r.rgb.r = val;
        r.rgb.g = val;
        r.rgb.b = val;
    } else {

        base = ((255 - sat) * val) >> 8;

        switch (hue / 60) {
            case 0:
            r.rgb.r = val;
            r.rgb.g = (((val - base) * hue) / 60) + base;
            r.rgb.b = base;
            break;
            case 1:
            r.rgb.r = (((val - base) * (60 - (hue % 60))) / 60) + base;
            r.rgb.g = val;
            r.rgb.b = base;
            break;

            case 2:
            r.rgb.r = base;
            r.rgb.g = val;
            r.rgb.b = (((val - base) * (hue % 60)) / 60) + base;
            break;

            case 3:
            r.rgb.r = base;
            r.rgb.g = (((val - base) * (60 - (hue % 60))) / 60) + base;
            r.rgb.b = val;
            break;

            case 4:
            r.rgb.r = (((val - base) * (hue % 60)) / 60) + base;
            r.rgb.g = base;
            r.rgb.b = val;
            break;

            case 5:
            r.rgb.r = val;
            r.rgb.g = base;
            r.rgb.b = (((val - base) * (60 - (hue % 60))) / 60) + base;
            break;

        }
    }
    return &r;
}


/*
 * Source: https://dystopiancode.blogspot.com/2012/06/hsv-rgb-conversion-algorithms-in-c.html
 */

hsvColor_t* rgb24ToHsv(const rgbColor24bpp_t* color)
{
	static hsvColor_t result;

	uint8_t maxVal = MAX(MAX(color->rgb.r, color->rgb.g), color->rgb.b);
	uint8_t minVal = MIN(MIN(color->rgb.r, color->rgb.g), color->rgb.b);
	uint8_t deltaVal = maxVal - minVal;

	result.h = 0;
	result.s = 0;
	result.v = maxVal;

	if (deltaVal > 0) {
		if (maxVal == color->rgb.r) {
			result.h = ((color->rgb.g - color->rgb.b) / deltaVal) % 6;
		} else if (maxVal == color->rgb.g) {
			result.h = (color->rgb.b - color->rgb.r) / deltaVal + 2;
		} else if (maxVal == color->rgb.b) {
			result.h = (color->rgb.r - color->rgb.g) / deltaVal + 4;
		}

		result.h *= 60;
		result.s = deltaVal / maxVal;
	}

	return &result;
}
