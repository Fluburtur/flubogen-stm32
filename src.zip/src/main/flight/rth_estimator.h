
#if defined(USE_ADC) && defined(USE_GPS)
float calculateRemainingFlightTimeBeforeRTH(bool takeWindIntoAccount);
float calculateRemainingDistanceBeforeRTH(bool takeWindIntoAccount);
#endif
