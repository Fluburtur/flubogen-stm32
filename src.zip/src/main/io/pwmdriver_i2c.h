
void pwmDriverInitialize(void);
void pwmDriverSync(void);
void pwmDriverSetPulse(uint8_t servoIndex, uint16_t length);
