
#pragma once

#ifdef USE_LIGHTS


bool lightsHardwareInit();
void lightsHardwareSetStatus(bool status);

#endif /* USE_LIGHTS */
